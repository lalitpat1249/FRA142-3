#pragma once
#include "Player.h"

class CoupGame;

class Action {
protected:
    Player* actor;
    Player* target;

public:
    Action(Player* actor, Player* target = nullptr);
    virtual ~Action() = default;

    virtual bool CheckBlockAble() = 0;
    virtual bool CheckChallengeAble() = 0;
    virtual void takeAction(CoupGame* game) = 0;

    Player* getActor() const;
    Player* getTarget() const;
};

class Income : public Action {
public:
    Income(Player* actor);
    bool CheckBlockAble() override;
    bool CheckChallengeAble() override;
    void takeAction(CoupGame* game) override;
};

class ForeignAid : public Action {
public:
    ForeignAid(Player* actor);
    bool CheckBlockAble() override;
    bool CheckChallengeAble() override;
    void takeAction(CoupGame* game) override;
};

class Tax : public Action {
public:
    Tax(Player* actor);
    bool CheckBlockAble() override;
    bool CheckChallengeAble() override;
    void takeAction(CoupGame* game) override;
};

class Steal : public Action {
public:
    Steal(Player* actor, Player* target);
    bool CheckBlockAble() override;
    bool CheckChallengeAble() override;
    void takeAction(CoupGame* game) override;
};

class Assassinate : public Action {
public:
    Assassinate(Player* actor, Player* target);
    bool CheckBlockAble() override;
    bool CheckChallengeAble() override;
    void takeAction(CoupGame* game) override;
};

class Exchange : public Action {
public:
    Exchange(Player* actor);
    bool CheckBlockAble() override;
    bool CheckChallengeAble() override;
    void takeAction(CoupGame* game) override;
};

class CoupAction : public Action {
public:
    CoupAction(Player* actor, Player* target);
    bool CheckBlockAble() override;
    bool CheckChallengeAble() override;
    void takeAction(CoupGame* game) override;
};