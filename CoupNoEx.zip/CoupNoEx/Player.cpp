#include "Player.h"
#include <iostream>

Player::Player(int id) : id(id), coins(2), aliveStatus(true) {}

int Player::getId() const { return id; }
int Player::getCoins() const { return coins; }
bool Player::isAlive() const { return aliveStatus; }

void Player::doAction() {
    std::cout << "Player " << id << " is choosing an action...\n";
}

void Player::addCard(Card card) {
    cards.push_back(card);
}

void Player::loseCard() {
    for (size_t i = 0; i < cards.size(); ++i) {
        if (!cards[i].isRevealed()) {
            cards[i].reveal();
            std::cout << " Card [" << cards[i].getTypeName() << "] of Player " << id << " has been revealed (Lost)!\n";
            
            bool allRevealed = true;
            for (const auto& card : cards) {
                if (!card.isRevealed()) allRevealed = false;
            }
            if (allRevealed) {
                aliveStatus = false;
                std::cout << " Player " << id << " has no active cards left and is ELIMINATED! \n";
            }
            return;
        }
    }
}

void Player::addCoins(int amount) {
    coins += amount;
}

void Player::loseCoins(int amount) {
    coins -= amount;
    if (coins < 0) coins = 0;
}

bool Player::checkCard(CardType type) const {
    for (const auto& card : cards) {
        if (!card.isRevealed() && card.getType() == type) {
            return true;
        }
    }
    return false;
}

bool Player::checkMaxCoin() const {
    return coins >= 10;
}

std::vector<Card>& Player::getCards() {
    return cards;
}