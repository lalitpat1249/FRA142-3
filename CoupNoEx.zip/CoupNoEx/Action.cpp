#include "Action.h"
#include "CoupGame.h"
#include <iostream>

Action::Action(Player* actor, Player* target) : actor(actor), target(target) {}
Player* Action::getActor() const { return actor; }
Player* Action::getTarget() const { return target; }

Income::Income(Player* actor) : Action(actor) {}
bool Income::CheckBlockAble() { return false; }
bool Income::CheckChallengeAble() { return false; }
void Income::takeAction(CoupGame* game) { actor->addCoins(1); }

ForeignAid::ForeignAid(Player* actor) : Action(actor) {}
bool ForeignAid::CheckBlockAble() { return true; }
bool ForeignAid::CheckChallengeAble() { return false; }
void ForeignAid::takeAction(CoupGame* game) { actor->addCoins(2); }

Tax::Tax(Player* actor) : Action(actor) {}
bool Tax::CheckBlockAble() { return false; }
bool Tax::CheckChallengeAble() { return true; }
void Tax::takeAction(CoupGame* game) { actor->addCoins(3); }

Steal::Steal(Player* actor, Player* target) : Action(actor, target) {}
bool Steal::CheckBlockAble() { return true; }
bool Steal::CheckChallengeAble() { return true; }
void Steal::takeAction(CoupGame* game) {
    if (target) {
        int stolen = (target->getCoins() >= 2) ? 2 : target->getCoins();
        target->loseCoins(stolen);
        actor->addCoins(stolen);
    }
}

Assassinate::Assassinate(Player* actor, Player* target) : Action(actor, target) {}
bool Assassinate::CheckBlockAble() { return true; }
bool Assassinate::CheckChallengeAble() { return true; }
void Assassinate::takeAction(CoupGame* game) {
    actor->loseCoins(3);
    if (target) {
        std::cout << " Player " << target->getId() << " is assassinated!\n";
        target->loseCard();
    }
}

Exchange::Exchange(Player* actor) : Action(actor) {}
bool Exchange::CheckBlockAble() { return false; }
bool Exchange::CheckChallengeAble() { return true; }
void Exchange::takeAction(CoupGame* game) {
    std::cout << "[Action] Player " << actor->getId() << " performs Exchange.\n";
}

CoupAction::CoupAction(Player* actor, Player* target) : Action(actor, target) {}
bool CoupAction::CheckBlockAble() { return false; }
bool CoupAction::CheckChallengeAble() { return false; }
void CoupAction::takeAction(CoupGame* game) {
    actor->loseCoins(7);
    if (target) {
        std::cout << " Player " << target->getId() << " is Couped!\n";
        target->loseCard();
    }
}