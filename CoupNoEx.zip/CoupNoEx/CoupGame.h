#pragma once
#include <vector>
#include "Player.h"
#include "Deck.h"
#include "Action.h"
#include "Systems.h"

class CoupGame {
private:
    std::vector<Player*> players;
    Deck deck;
    int currentTurn;
    ChallengeSystem challengeSys;
    BlockSystem blockSys;

public:
    CoupGame();
    ~CoupGame();

    void startGame(int amountPlayer);
    void nextTurn();
    void performAction(Player* actor, Action* action);
    bool performChallengePhase(Player* actor, Action* action);
    bool performBlockPhase(Player* actor, Action* action);
    bool checkWin();
    
    Player* getCurrentPlayer();
    Player* getPlayerById(int id);
    int getNumPlayers() const;

    Card drawCardFromDeck();
    void returnCardToDeck(Card card);
};