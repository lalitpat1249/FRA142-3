#include "CoupGame.h"
#include "Action.h"
#include "Card.h"
#include <iostream>
#include <limits>
#include <cstdlib>
#include <vector>

void clearInput() {
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

void clearScreen() {
#ifdef _WIN32
    std::system("cls");
#else
    std::system("clear");
#endif
}

void waitForPlayerConfirm(int playerId) {
    std::cout << "\n--------------------------------------------------\n";
    std::cout << "  [SECRET] TURN FOR PLAYER " << playerId << " ONLY!\n";
    std::cout << "  Please ask other players to look away.\n";
    std::cout << "--------------------------------------------------\n";
    std::cout << "Press Enter when only Player " << playerId << " is looking at the screen...";
    std::cin.get();
    clearScreen();
}

void displayPublicBoardStatus(CoupGame& game) {
    std::cout << "\n========= CURRENT BOARD STATUS (PUBLIC) =========\n";
    for (int i = 1; i <= game.getNumPlayers(); ++i) {
        Player* p = game.getPlayerById(i);
        std::cout << "Player " << p->getId() << " -> Coins: " << p->getCoins() << " | Status: ";
        if (p->isAlive()) {
            int activeCards = 0;
            for (const auto& c : p->getCards()) { if (!c.isRevealed()) activeCards++; }
            std::cout << " ALIVE (" << activeCards << " Secret Cards)\n";
        } else {
            std::cout << " DEAD\n";
        }
        for (const auto& c : p->getCards()) {
            if (c.isRevealed()) {
                std::cout << "   ↳ Revealed Card: [" << c.getTypeName() << "]\n";
            }
        }
    }
    std::cout << "=================================================\n";
}

void displayPrivateStatus(Player* p) {
    std::cout << "[YOUR SECRET HAND] Player " << p->getId() << "\n";
    std::cout << "Your Coins: " << p->getCoins() << "\n";
    std::cout << "Your Active Cards: ";
    
    std::vector<Card>& hand = p->getCards();
    for (size_t i = 0; i < hand.size(); ++i) {
        if (!hand[i].isRevealed()) {
            std::cout << "[" << i << "]: " << hand[i].getTypeName() << "   ";
        }
    }
    std::cout << "\n-------------------------------------------------\n";
}

int main() {
    CoupGame game;
    int numPlayers;

    std::cout << "===========================================\n";
    std::cout << "      COUP BOARD GAME (OOP C++ EDITION)    \n";
    std::cout << "===========================================\n";
    
    std::cout << "Enter number of players (2-4): ";
    while (!(std::cin >> numPlayers) || numPlayers < 2 || numPlayers > 4) {
        std::cout << "Invalid. Please enter 2-4: ";
        clearInput();
    }

    game.startGame(numPlayers);
    clearInput();

    for (int i = 1; i <= numPlayers; ++i) {
        Player* p = game.getPlayerById(i);
        waitForPlayerConfirm(p->getId());
        displayPrivateStatus(p);
        
        std::cout << "\nRemember your cards well! Press Enter to hide and pass to the next player...";
        std::cin.get();
        clearScreen();
    }
    
    std::cout << "\n[System] All players have checked their cards. The game begins now!\n";
    std::cout << "Press Enter to start the first turn...";
    std::cin.get();
    clearScreen();

    while (true) {
        displayPublicBoardStatus(game);
        if (game.checkWin()) break;

        game.nextTurn();
        Player* actor = game.getCurrentPlayer();
        
        waitForPlayerConfirm(actor->getId());
        displayPrivateStatus(actor);

        if (actor->checkMaxCoin()) {
            std::cout << " You have 10 or more coins! You are FORCED to Coup.\n";
        }

        int choice = 0;
        Action* selectedAction = nullptr;
        Player* targetPlayer = nullptr;

        while (selectedAction == nullptr) {
            if (actor->checkMaxCoin()) { choice = 7; } 
            else {
                std::cout << "Select your Action:\n";
                std::cout << "[1] Income       [2] Foreign Aid   [3] Tax (Duke)\n";
                std::cout << "[4] Steal (Capt) [5] Assassinate  [6] Exchange (Amb)\n";
                std::cout << "[7] Coup\n";
                std::cout << "Enter choice (1-7): ";
                if (!(std::cin >> choice) || choice < 1 || choice > 7) {
                    std::cout << "Invalid choice. Try again.\n";
                    clearInput();
                    continue;
                }
            }

            if (choice == 4 || choice == 5 || choice == 7) {
                int targetId;
                std::cout << "Enter Target Player ID: ";
                std::cin >> targetId;
                targetPlayer = game.getPlayerById(targetId);

                if (!targetPlayer || targetPlayer->getId() == actor->getId() || !targetPlayer->isAlive()) {
                    std::cout << " Invalid target!\n";
                    if (actor->checkMaxCoin()) continue;
                    selectedAction = nullptr;
                    continue;
                }
            }

            if ((choice == 5 && actor->getCoins() < 3) || (choice == 7 && actor->getCoins() < 7)) {
                std::cout << "Not enough coins!\n";
                continue;
            }

            switch (choice) {
                case 1: selectedAction = new Income(actor); break;
                case 2: selectedAction = new ForeignAid(actor); break;
                case 3: selectedAction = new Tax(actor); break;
                case 4: selectedAction = new Steal(actor, targetPlayer); break;
                case 5: selectedAction = new Assassinate(actor, targetPlayer); break;
                case 6: selectedAction = new Exchange(actor); break;
                case 7: selectedAction = new CoupAction(actor, targetPlayer); break;
            }
        }

        bool proceedAction = game.performChallengePhase(actor, selectedAction);
        if (proceedAction) {
            proceedAction = game.performBlockPhase(actor, selectedAction);
        }

        if (proceedAction) {
            game.performAction(actor, selectedAction);
            
            if (choice == 6) {
                std::cout << "\n---  EXCHANGE SYSTEM INTERACTIVE  ---\n";
                Card newCard1 = game.drawCardFromDeck();
                Card newCard2 = game.drawCardFromDeck();
                
                std::cout << "You drew 2 cards from deck:\n";
                std::cout << "[0]: " << newCard1.getTypeName() << "\n";
                std::cout << "[1]: " << newCard2.getTypeName() << "\n";
                
                std::vector<Card> pool;
                pool.push_back(newCard1);
                pool.push_back(newCard2);
                
                std::vector<Card>& oldHand = actor->getCards();
                int originalActiveCount = 0;
                
                for(const auto& c : oldHand) {
                    if(!c.isRevealed()) {
                        pool.push_back(c);
                        originalActiveCount++;
                    }
                }
                
                std::cout << "\nYour available pool of active cards:\n";
                for(size_t i = 0; i < pool.size(); ++i) {
                    std::cout << "[" << i << "]: " << pool[i].getTypeName() << "\n";
                }
                
                std::vector<Card> newHand;
                std::vector<bool> keptIndices(pool.size(), false);
                std::cout << "\nYou must choose " << originalActiveCount << " card(s) to KEEP.\n";
                for(int k = 0; k < originalActiveCount; ++k) {
                    int keepIdx;
                    while (true) {
                        std::cout << "Enter index of card to KEEP for slot " << k+1 << ": ";
                        std::cin >> keepIdx;
                        if (keepIdx >= 0 && keepIdx < (int)pool.size() && !keptIndices[keepIdx]) {
                            keptIndices[keepIdx] = true;
                            newHand.push_back(pool[keepIdx]);
                            break;
                        }
                        std::cout << "Invalid or already chosen index. Try again.\n";
                    }
                }
                
                for(size_t i = 0; i < pool.size(); ++i) {
                    if(!keptIndices[i]) {
                        game.returnCardToDeck(pool[i]);
                    }
                }
                
                oldHand.clear();
                for(const auto& kh : newHand) {
                    oldHand.push_back(kh);
                }
                
                std::cout << "Exchange completed successfully!\n";
            } else {
                std::cout << "Action Executed Successfully!\n";
            }
        } else {
            std::cout << "Action Was Cancelled or Failed.\n";
        }

        delete selectedAction; 
        
        std::cout << "\nEnd of turn. Press Enter to clean screen and pass control...";
        clearInput();
        std::cin.get();
        clearScreen(); 
    }

    std::cout << "\n=== Thank you for playing Coup Game ===\n";

    std::cout << "\nPress Enter to exit the application...";
    std::cin.get(); 

    return 0;
}