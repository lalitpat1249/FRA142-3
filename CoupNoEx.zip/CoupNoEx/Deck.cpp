#include "Deck.h"
#include <algorithm>
#include <random>
#include <chrono>
#include <stdexcept>

Deck::Deck() {
    for (int i = 0; i < 3; ++i) {
        cards.push_back(Card(CardType::Duke));
        cards.push_back(Card(CardType::Assassin));
        cards.push_back(Card(CardType::Captain));
        cards.push_back(Card(CardType::Ambassador));
        cards.push_back(Card(CardType::Contessa));
    }
}

void Deck::shuffle() {
    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::shuffle(cards.begin(), cards.end(), std::default_random_engine(seed));
}

Card Deck::drawCard() {
    if (cards.empty()) {
        throw std::runtime_error("Deck is empty!");
    }
    Card drawn = cards.back();
    cards.pop_back();
    return drawn;
}

void Deck::GainCard(Card card) {
    cards.push_back(card);
}

int Deck::getSize() const {
    return cards.size();
}