#pragma once
#include "Player.h"
#include "Action.h"

class ChallengeSystem {
public:
    bool challenge(Player* challenger, Player* challenged, Action* action);
};

class BlockSystem {
public:
    bool block(Player* blocker, Player* blocked, Action* action);
};