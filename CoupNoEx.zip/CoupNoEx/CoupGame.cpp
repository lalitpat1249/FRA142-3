#include "CoupGame.h"
#include "Card.h"
#include "Action.h"
#include <iostream>

CoupGame::CoupGame() : currentTurn(-1) {}

CoupGame::~CoupGame() {
    for (Player* p : players) { delete p; }
    players.clear();
}

void CoupGame::startGame(int amountPlayer) {
    deck.shuffle();
    for (int i = 1; i <= amountPlayer; ++i) {
        Player* p = new Player(i);
        p->addCard(deck.drawCard());
        p->addCard(deck.drawCard());
        players.push_back(p);
    }
    std::cout << "\n[System] Game started with " << amountPlayer << " players.\n";
}

void CoupGame::nextTurn() {
    do {
        currentTurn = (currentTurn + 1) % players.size();
    } while (!players[currentTurn]->isAlive());
}

Player* CoupGame::getCurrentPlayer() {
    return players[currentTurn];
}

Player* CoupGame::getPlayerById(int id) {
    for (Player* p : players) {
        if (p->getId() == id) return p;
    }
    return nullptr;
}

int CoupGame::getNumPlayers() const {
    return players.size();
}

Card CoupGame::drawCardFromDeck() {
    return deck.drawCard();
}

void CoupGame::returnCardToDeck(Card card) {
    deck.GainCard(card);
    deck.shuffle();
}

bool CoupGame::performChallengePhase(Player* actor, Action* action) {
    if (!action->CheckChallengeAble()) return true;

    for (Player* p : players) {
        if (p->isAlive() && p->getId() != actor->getId()) {
            char choice;
            std::cout << "-> Player " << p->getId() << ", do you want to CHALLENGE Player " << actor->getId() << "? (y/n): ";
            std::cin >> choice;
            
            if (choice == 'y' || choice == 'Y') {
                std::cout << " Player " << p->getId() << " CHALLENGES Player " << actor->getId() << "!\n";
                std::cout << " System is checking Player " << actor->getId() << "'s hand...\n";

                CardType requiredType = CardType::Duke;
                bool hasCard = false;
                if (dynamic_cast<Tax*>(action)) { hasCard = actor->checkCard(CardType::Duke); requiredType = CardType::Duke; }
                else if (dynamic_cast<Steal*>(action)) { hasCard = actor->checkCard(CardType::Captain); requiredType = CardType::Captain; }
                else if (dynamic_cast<Assassinate*>(action)) { hasCard = actor->checkCard(CardType::Assassin); requiredType = CardType::Assassin; }
                else if (dynamic_cast<Exchange*>(action)) { hasCard = actor->checkCard(CardType::Ambassador); requiredType = CardType::Ambassador; }

                if (!hasCard) {
                    std::cout << " Challenge Success! Player " << actor->getId() << " was bluffing!\n";
                    actor->loseCard();
                    return false;
                } else {
                    std::cout << " Challenge Failed! Player " << actor->getId() << " HAS the card!\n";
                    std::cout << " Player " << p->getId() << " loses a card for false accusation!\n";
                    p->loseCard();
                    
                    std::vector<Card>& actorHand = actor->getCards();
                    for (size_t i = 0; i < actorHand.size(); ++i) {
                        if (!actorHand[i].isRevealed() && actorHand[i].getType() == requiredType) {
                            std::cout << " [Rule] Player " << actor->getId() << " returns [" << actorHand[i].getTypeName() << "] to the deck and draws a new card!\n";
                            
                            Card replacementCard = drawCardFromDeck();
                            returnCardToDeck(actorHand[i]);
                            actorHand[i] = replacementCard;
                            
                            std::cout << " [SECRET INFO] Player " << actor->getId() << ", your new card is: [" << actorHand[i].getTypeName() << "]\n";
                            break;
                        }
                    }
                    return true;
                }
            }
        }
    }
    return true;
}

bool CoupGame::performBlockPhase(Player* actor, Action* action) {
    if (!action->CheckBlockAble()) return true;

    for (Player* p : players) {
        if (p->isAlive() && p->getId() != actor->getId()) {
            char choice;
            std::cout << "-> Player " << p->getId() << ", do you want to BLOCK Player " << actor->getId() << "'s action? (y/n): ";
            std::cin >> choice;
            
            if (choice == 'y' || choice == 'Y') {
                std::cout << " Player " << p->getId() << " claims to BLOCK the action!\n";
                
                bool blockChallenged = false;
                Player* blockChallenger = nullptr;

                for (Player* c : players) {
                    if (c->isAlive() && c->getId() != p->getId()) {
                        char chalChoice;
                        std::cout << "   --> Player " << c->getId() << ", do you want to CHALLENGE Player " << p->getId() << "'s BLOCK? (y/n): ";
                        std::cin >> chalChoice;
                        if (chalChoice == 'y' || chalChoice == 'Y') {
                            blockChallenged = true;
                            blockChallenger = c;
                            break;
                        }
                    }
                }

                if (blockChallenged) {
                    std::cout << " Player " << blockChallenger->getId() << " CHALLENGES Player " << p->getId() << "'s block!\n";
                    std::cout << " System is checking Blocker (Player " << p->getId() << ")'s hand...\n";

                    bool blockHasCard = false;
                    CardType blockRequiredType = CardType::Duke;

                    if (dynamic_cast<ForeignAid*>(action)) {
                        blockHasCard = p->checkCard(CardType::Duke);
                        blockRequiredType = CardType::Duke;
                    } else if (dynamic_cast<Steal*>(action)) {
                        if (p->checkCard(CardType::Captain)) { blockHasCard = true; blockRequiredType = CardType::Captain; }
                        else if (p->checkCard(CardType::Ambassador)) { blockHasCard = true; blockRequiredType = CardType::Ambassador; }
                    } else if (dynamic_cast<Assassinate*>(action)) {
                        blockHasCard = p->checkCard(CardType::Contessa);
                        blockRequiredType = CardType::Contessa;
                    }

                    if (!blockHasCard) {
                        std::cout << " Challenge Success! Blocker (Player " << p->getId() << ") was bluffing!\n";
                        p->loseCard();
                        return true;
                    } else {
                        std::cout << " Challenge Failed! Blocker (Player " << p->getId() << ") HAS the card!\n";
                        std::cout << " Player " << blockChallenger->getId() << " loses a card for false accusation!\n";
                        blockChallenger->loseCard();
                        
                        std::vector<Card>& blockerHand = p->getCards();
                        for (size_t i = 0; i < blockerHand.size(); ++i) {
                            if (!blockerHand[i].isRevealed() && blockerHand[i].getType() == blockRequiredType) {
                                std::cout << " [Rule] Blocker (Player " << p->getId() << ") returns [" << blockerHand[i].getTypeName() << "] to the deck and draws a new card!\n";
                                
                                Card replacementCard = drawCardFromDeck();
                                returnCardToDeck(blockerHand[i]);
                                blockerHand[i] = replacementCard;
                                
                                std::cout << " [SECRET INFO] Blocker (Player " << p->getId() << "), your new card is: [" << blockerHand[i].getTypeName() << "]\n";
                                break;
                            }
                        }
                        return false;
                    }
                } else {
                    std::cout << " Nobody challenged the block. Action successfully BLOCKED by Player " << p->getId() << ".\n";
                    return false;
                }
            }
        }
    }
    return true;
}

void CoupGame::performAction(Player* actor, Action* action) {
    action->takeAction(this);
}

bool CoupGame::checkWin() {
    int aliveCount = 0;
    Player* winner = nullptr;
    for (Player* p : players) {
        if (p->isAlive()) {
            aliveCount++;
            winner = p;
        }
    }
    if (aliveCount == 1 && winner != nullptr) {
        std::cout << "\n GAME OVER! PLAYER " << winner->getId() << " WINS THE GAME! \n";
        return true;
    }
    return false;
}