#pragma once
#include <string>

enum class CardType { Duke, Assassin, Captain, Ambassador, Contessa };

class Card {
private:
    CardType type;
    bool revealCard;

public:
    Card(CardType t);
    CardType getType() const;
    bool isRevealed() const;
    void reveal();
    std::string getTypeName() const;
};