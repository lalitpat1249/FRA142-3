#include "Systems.h"
#include <iostream>

bool ChallengeSystem::challenge(Player* challenger, Player* challenged, Action* action) {
    return true;
}

bool BlockSystem::block(Player* blocker, Player* blocked, Action* action) {
    return true;
}