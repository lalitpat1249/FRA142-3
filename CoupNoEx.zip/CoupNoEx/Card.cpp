#include "Card.h"

Card::Card(CardType t) : type(t), revealCard(false) {}

CardType Card::getType() const { return type; }

bool Card::isRevealed() const { return revealCard; }

void Card::reveal() { revealCard = true; }

std::string Card::getTypeName() const {
    switch (type) {
        case CardType::Duke: return "Duke";
        case CardType::Assassin: return "Assassin";
        case CardType::Captain: return "Captain";
        case CardType::Ambassador: return "Ambassador";
        case CardType::Contessa: return "Contessa";
        default: return "Unknown";
    }
}