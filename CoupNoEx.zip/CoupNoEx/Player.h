#pragma once
#include <vector>
#include <string>
#include "Card.h"

class Player {
private:
    int id;
    int coins;
    std::vector<Card> cards;
    bool aliveStatus;

public:
    Player(int id);
    int getId() const;
    int getCoins() const;
    bool isAlive() const;
    
    void doAction();
    void addCard(Card card);
    void loseCard();
    void addCoins(int amount);
    void loseCoins(int amount);
    bool checkCard(CardType type) const;
    bool checkMaxCoin() const;
    
    std::vector<Card>& getCards();
};